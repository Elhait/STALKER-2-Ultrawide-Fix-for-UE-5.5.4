# STALKER2CameraTweaks — UE4SS parallel prototype

This folder is a separate UE4SS implementation with the same module name as
the production ASI. It ports the current gameplay, cinematic and dialogue
policies where UE4SS exposes safe value/property operations.

## Important status

This is a test prototype, not a replacement release. It does not use hardcoded
object IDs, raw native offsets, native hooks or undocumented ref/out calls.
It also does not claim that a reflected property write rebuilds the complete
UE camera/projection pipeline. The UE4SS log explicitly records accepted writes
and their route for later in-game comparison.

## Installation

Copy this folder as:

`Stalker2\Binaries\Win64\ue4ss\Mods\STALKER2CameraTweaks`

The required module entry is:

`STALKER2CameraTweaks : 1`

Keep the included `STALKER2CameraTweaks.ini` beside `Scripts\main.lua` in the
module folder.

## Test isolation

For a UE4SS test, disable the production `STALKER2CameraTweaks.asi` and any
older camera-writing UE4SS module. Keep UE4SS enabled. Do not run this module
and the ASI together because both can write the same camera state.

`End` forces one immediate state record. It does not change camera values.

## Ported behavior

- Dynamic discovery of the player `CameraComponent`, `CameraManager` bridge and
  `PlayerCameraManager`.
- Re-discovery after object invalidation/replacement.
- Gameplay wide-state normalization toward the proven final native gameplay
  state (`FOV` preserved, `AspectRatio=16:9`, unconstrained), subject to the
  limitation that UE4SS cannot prove the native two-pass rebuild.
- Configurable cinematic `Auto`/`Native`/`16:9`/`21:9`/`32:9` policy and the
  existing Hor+ conversion when `PreserveAuthoredFOV=false`.
- Configurable `Native`/`Adaptive`/`Reduced`/`Disabled` dialogue zoom model.
- Change-only state logging for camera and PCM current/last/target POV.

## Not yet proven

- Native cinematic projection reevaluation after a property write.
- Exact causal ownership of letterbox creation/removal.
- Safe invocation of `GetCameraView` or `BlueprintUpdateCamera` with ref/out
  structures.
- Production equivalence across game builds or all cinematic types.

The production ASI remains the stable fallback until this prototype has
repeatable gameplay, cinematic-entry/exit and dialogue evidence.
