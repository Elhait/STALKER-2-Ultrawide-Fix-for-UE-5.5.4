# STALKER 2 Gameplay Aspect Fix

An ASI plugin for **S.T.A.L.K.E.R. 2: Heart of Chornobyl** that fixes the incorrect gameplay camera state on ultrawide displays after the UE 5.5 game update.

## What It Fixes

- Replays the camera-state transition that the game performs when the user manually applies `16:9 -> Auto`.
- Corrects the initial 32:9 gameplay view without forcing a FOV value.
- Re-arms the same transition when it detects the exact gameplay-camera rebuild state seen after a cutscene.
- Preserves the FOV selected in the game settings.
- Keeps constrained aspect-ratio behavior for a real 21:9 output.

## Tested Build

- Steam game build: `2.0.2`
- Engine: UE `5.5.6`
- Executable fingerprint: timestamp `0x60AB1AA8`, image size `0x0B94D000`
- Tested display modes: `5120x1440` (32:9) and `3440x1440` (custom 21:9).

The plugin checks the executable fingerprint before it hooks anything. After a game update it will safely refuse to activate and record the reason in the log.

## Installation

1. Install [Ultimate ASI Loader](https://github.com/ThirteenAG/Ultimate-ASI-Loader) as `dsound.dll` in `Stalker2\\Binaries\\Win64`.
2. Copy `STALKER2GameplayAspectFix.asi` to the same `Win64` directory.
3. Remove previous experimental `STALKER2*.asi` files before launching the game.
4. Start the game normally. No INI configuration is required.

The plugin creates `STALKER2GameplayAspectFix.log` beside the game executable on each launch.

## Scope And Known Limitations

- This release fixes **gameplay camera/aspect behavior only**.
- Cutscene letterboxing and cutscene FOV are not included in this first release. Work on those fixes is ongoing.
- I tested integrating the [BigChenga Ultrawide / Flawless Widescreen solution](https://www.nexusmods.com/stalker2heartofchornobyl/mods/2337?tab=description), but bugs remain in that integration. I am investigating a stable solution before releasing it.
- The plugin is currently validated only for the Steam 2.0.2 executable listed above.
- If the game is updated, wait for a compatible release instead of bypassing the executable check.
- Before public release, perform one final visual smoke test by completing a cutscene and confirming the gameplay view is restored automatically.

## Authorship And Credits

- Gameplay camera investigation, validated hook, state-transition logic, and this release: **Elhait**.
- This is an independent gameplay-only mod, not a release of Lyall's STALKER2Tweak.
- Parts of the helper and ASI-plugin scaffolding were initially derived from Lyall's MIT-licensed project. See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

- [Ultimate ASI Loader](https://github.com/ThirteenAG/Ultimate-ASI-Loader) for ASI loading.
- [SafetyHook](https://github.com/cursey/safetyhook) and [Zydis](https://github.com/zyantific/zydis) for validated runtime hooking.
- [Dumper-7](https://github.com/Encryqed/Dumper-7) and Ghidra for the reverse-engineering workflow.

See [TESTING_AND_RESEARCH.md](TESTING_AND_RESEARCH.md) for the technical investigation and discarded approaches.
