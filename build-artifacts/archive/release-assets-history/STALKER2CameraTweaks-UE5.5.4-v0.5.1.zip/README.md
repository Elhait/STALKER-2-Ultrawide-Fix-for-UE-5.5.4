# STALKER 2 Camera Tweaks — v0.5.1

This hotfix corrects `Cinematics.AspectRatio=Auto` after the gameplay aspect transition.

The mod-owned native-aspect restore is no longer written back into the authoritative Auto-aspect cache. Auto cinematics therefore retain the runtime display aspect detected before the restore.

Validated on Steam build 2.0.4 with the UE 5.5.4 target:

- Windows 21:9: Auto cinematic ENTER uses aspect `2.38889`.
- Windows 32:9: Auto cinematic ENTER uses aspect `3.55556`.
- Repeated cinematic ENTER/EXIT and gameplay recovery pass on both tested aspect ratios.

This hotfix does not change the Hor+ FOV algorithm, dialogue zoom, subtitle positioning, or the existing Full Hor+ production behavior.

## Installation

1. Keep Ultimate ASI Loader installed with `dsound.dll` in `Stalker2\\Binaries\\Win64`.
2. Remove the old `STALKER2CameraTweaks.asi` before copying this hotfix.
3. Copy `STALKER2CameraTweaks.asi` and `STALKER2CameraTweaks.ini` into the same Win64 directory.
4. Do not load the old `STALKER2UltrawideFix.asi` or `STALKER2GameplayAspectFix.asi` alongside it.
5. Restart the game after installation.

The runtime log is written to `STALKER2CameraTweaks.log` beside the ASI.
