# STALKER 2 Ultrawide Fix for UE 5.5.4 — Gameplay, Cinematics & Custom Framing

## Version 0.4.0

An ASI plugin for **S.T.A.L.K.E.R. 2: Heart of Chornobyl** that corrects
ultrawide gameplay and cinematic framing for the Steam build tested with
Unreal Engine `5.5.4`.

## Features

- Corrects gameplay aspect transitions on 21:9 and 32:9 displays.
- Re-arms the gameplay correction after camera rebuilds, including death/load.
- Preserves the FOV selected in the game settings.
- Corrects cinematic aspect and applies Hor+ cinematic FOV.
- Uses the game's runtime camera aspect rather than desktop dimensions.
- Dynamically follows `Auto` aspect changes during the same game session without requiring a restart.
- Supports custom cinematic framing independent of the physical display:
  `Auto`, `Native`, `16:9`, `21:9` or `32:9`.
- Creates `STALKER2UltrawideFix.ini` automatically when it is missing.
- Resolves gameplay and cinematic hook locations through guarded signatures and
  refuses safely when validation is ambiguous or fails.

## Configuration

```ini
[Gameplay]
Enabled=true

[Cinematics]
; Auto, Native, 16:9, 21:9, 32:9
AspectRatio=Auto
```

`Auto` follows the game's runtime camera aspect and applies matching Hor+ FOV.
It also updates when the game resolution changes during the same session.
`Native` leaves the game's cinematic aspect and FOV behavior untouched. Forced
modes are useful for custom cinematic framing; for example, forcing `32:9` on a
16:9 display produces a letterboxed cinematic presentation with matching FOV.

Configuration changes take effect after restarting the game.

## Installation

1. Install [Ultimate ASI Loader](https://github.com/ThirteenAG/Ultimate-ASI-Loader)
   as `dsound.dll` in `Stalker2\\Binaries\\Win64`.
2. Remove the previous `STALKER2GameplayAspectFix.asi` and its old INI/log
   before installing this unified mod. Do not load both ASIs together.
3. Copy `STALKER2UltrawideFix.asi` and `STALKER2UltrawideFix.ini` to the same
   `Win64` directory.
4. Start the game normally.

The plugin creates `STALKER2UltrawideFix.log` beside the game executable. The
startup log includes the SHA-256 of the loaded mod and game executable, which
helps verify support reports.

## Tested scope and limitations

- Runtime-tested on Steam game build `2.0.4` with the validated executable
  SHA-256 recorded in the startup log.
- Gameplay was tested at 21:9 and 32:9, including startup, hot aspect switching,
  death/load rebuild and FOV preservation.
- `Auto` cinematics were tested through `16:9 → 21:9 → 32:9 → 16:9 → 21:9 → 32:9`
  without restarting the game.
- Cinematics were tested with `Native`, forced `16:9`, forced `21:9` and forced
  `32:9` policies on `5120x1440`.
- Forced 32:9 framing was also tested at `2560x1440` and correctly produced
  cinematic letterbox bars.
- The brief post-cinematic projection/FOV handoff transition may still be
  visible in some scenarios.
- Weapon/viewmodel FOV after loading on 21:9 is a separate known game issue and
  is not fixed by this mod.
- Changing the game resolution during a session is validated for
  `AspectRatio=Auto`; restart the game after changing the configuration file
  itself.
- Signature resolution improves resilience to address relocation but does not
  guarantee compatibility with future patches. Do not bypass a safe refusal;
  wait for a version-specific validation.

## Credits and notices

- Gameplay and cinematic investigation, implementation and release: **Elhait**.
- Independent mod; not a release of Lyall's STALKER2Tweak.
- See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) for dependency notices.
- Runtime support uses [SafetyHook](https://github.com/cursey/safetyhook) and
  [Zydis](https://github.com/zyantific/zydis). Ghidra and Dumper-7 were used
  during reverse-engineering.
