# Third-Party Notices

## Lyall - STALKER2Tweak

Parts of the helper and ASI-plugin scaffolding were initially derived from
[Lyall's STALKER2Tweak](https://github.com/Lyall/STALKER2Tweak). The gameplay
camera investigation, validated hook, state-transition logic, release scope,
and documentation in this project were developed independently by Elhait.

The derived portions remain subject to the following MIT License:

```text
MIT License

Copyright (c) 2024 Lyall

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Runtime And Analysis Dependencies

- Ultimate ASI Loader
- SafetyHook and Zydis
- spdlog
- Dumper-7 and Ghidra, used during analysis only

Refer to the upstream projects for their respective license terms.
